# 🤖 Bot Vinted IA - Automatisation d'annonces

Bot intelligent qui analyse automatiquement vos photos de vêtements/accessoires et génère des annonces Vinted complètes avec l'API Claude.

## ✨ Fonctionnalités

- 📸 **Upload multi-photos** (jusqu'à 5 images)
- 🎯 **Analyse IA ultra-précise** avec Claude Sonnet 4
- 🌍 **Multilingue** (Français, English, Español, Deutsch)
- ✏️ **Édition facile** des résultats
- 📋 **Copie rapide** en un clic
- 🎨 **Design moderne** avec animations
- 🔄 **Drag & drop** pour upload
- 💰 **Prix intelligents** basés sur le type et la marque

## 🚀 Déploiement sur Render (GRATUIT)

### Méthode 1 : Déploiement automatique

1. **Créer un compte sur [Render.com](https://render.com)**

2. **Pousser le code sur GitHub** :
```bash
git init
git add .
git commit -m "Initial commit - Bot Vinted IA"
git remote add origin VOTRE_REPO_URL
git push -u origin main
```

3. **Sur Render** :
   - Cliquer sur "New +" → "Web Service"
   - Connecter votre repo GitHub
   - Render détecte automatiquement le `render.yaml`
   - Cliquer sur "Create Web Service"

4. **Attendre 2-3 minutes** pour le build

5. **Votre bot est en ligne !** 🎉

### Méthode 2 : Configuration manuelle

1. Sur Render → "New +" → "Web Service"
2. Connecter le repo
3. Configuration :
   - **Name** : `vinted-bot-ia`
   - **Runtime** : Python 3
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 120`

## 🏠 Lancement en local

```bash
# Installer les dépendances
pip install -r requirements.txt

# Lancer le serveur
python app.py
```

Ouvrir http://localhost:5000

## 📝 Utilisation

1. **Uploader vos photos** (drag & drop ou clic)
2. **Choisir la langue** (FR/EN/ES/DE)
3. **Cliquer sur "Analyser avec l'IA"**
4. **Modifier si besoin** (tous les champs sont éditables)
5. **Copier les infos** (bouton copie par champ ou tout copier)

## 🎯 Précision de l'analyse

Le bot détecte avec précision :

- ✅ **Type exact** : Maillot Bayern Munich, T-shirt, Pull, Sweat, Pantalon, Chaussures, Sac
- ✅ **Marques** : Équipes sportives (Bayern, Real Madrid, PSG...), Nike, Adidas, Puma, etc.
- ✅ **Couleurs** : Rouge, Bleu, Noir, Blanc, Gris, Vert, etc.
- ✅ **État** : Neuf, Très bon état, Bon état, Satisfaisant
- ✅ **Prix réaliste** : Basé sur type + marque + état
- ✅ **Titre accrocheur** : Optimisé pour Vinted
- ✅ **Description détaillée** : 3-4 phrases attractives

## 🔧 Technologies

- **Backend** : Flask (Python)
- **IA** : Claude Sonnet 4 API (Anthropic)
- **Frontend** : HTML/CSS/JavaScript vanilla
- **Design** : Glassmorphism + animations CSS
- **Hébergement** : Render (gratuit)

## 📦 Structure du projet

```
vinted-bot-ia/
├── app.py                 # Application Flask principale
├── requirements.txt       # Dépendances Python
├── Procfile              # Config Gunicorn
├── render.yaml           # Config Render
├── .gitignore           # Fichiers à ignorer
└── README.md            # Documentation
```

## 🎨 Aperçu du design

- **Glassmorphism** : Cartes en verre avec blur
- **Gradient animé** : Fond violet-rose dynamique
- **Animations fluides** : Hover, transitions, bounce
- **Responsive** : S'adapte à tous les écrans
- **Dark mode ready** : Palette de couleurs moderne

## ⚙️ Configuration

Le bot fonctionne sans configuration ! L'API Claude est appelée directement depuis le frontend via CORS.

Pour une utilisation en production avec votre propre clé API :
1. Créer un fichier `.env`
2. Ajouter : `ANTHROPIC_API_KEY=votre_cle`
3. Modifier `app.py` pour lire la clé depuis l'environnement

## 🆘 Dépannage

### L'analyse ne fonctionne pas
- ✅ Vérifier que les photos sont au format JPG/PNG
- ✅ Taille max : 5 photos de 10MB chacune
- ✅ Vérifier la console du navigateur pour les erreurs

### Le serveur ne démarre pas sur Render
- ✅ Vérifier que `requirements.txt` est présent
- ✅ Vérifier les logs de build sur Render
- ✅ Le port est automatiquement assigné par Render

### Les résultats sont en "À préciser"
- ✅ Photos trop floues → prendre des photos nettes
- ✅ API Claude surchargée → réessayer dans 1 minute
- ✅ Timeout réseau → vérifier la connexion

## 📈 Améliorations futures

- [ ] Sauvegarde des annonces créées
- [ ] Export PDF des annonces
- [ ] Publication directe sur Vinted (avec Selenium)
- [ ] Statistiques des prix du marché
- [ ] Suggestions d'amélioration des photos
- [ ] Support de plus de langues

## 📄 Licence

MIT License - Libre d'utilisation

## 👨‍💻 Auteur

Créé avec ❤️ pour faciliter la vente sur Vinted

---

**Astuce** : Pour de meilleurs résultats, prenez des photos nettes avec un bon éclairage et plusieurs angles du produit !
